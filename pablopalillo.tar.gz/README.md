# pablopalillo
Sitio Web personal de Pablo Martinez.

Creado en Python con su Framework Django. 
Si tienes alguna duda sobre las funcionalidades creadas en este proyecto puedes dirigirte a la documentacion de Django https://docs.djangoproject.com/en/1.9/ Donde te explica paso a paso como hacerlo desde 0.

En el papel esta que este proyecto funcione como portafolios de servicios ademas de tener enlaces a otros micrositios que mas adelante se implementaras y documentaran.
Contaran con articulos con CEO y categorizadas.
Este proyecto es Open Source, puedes tenerlo y leer toda la fuente en este repositorio.
