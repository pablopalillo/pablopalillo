-- MySQL dump 10.13  Distrib 5.5.58, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pablopalillo
-- ------------------------------------------------------
-- Server version	5.5.58-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articulo`
--

DROP TABLE IF EXISTS `articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulo` (
  `id_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(300) DEFAULT NULL,
  `contenido` text,
  `slug` varchar(300) DEFAULT NULL,
  `tipo` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id_articulo`),
  KEY `fk_art_tip` (`tipo`),
  KEY `fk_art_est` (`estado`),
  CONSTRAINT `articulo_ibfk_1` FOREIGN KEY (`tipo`) REFERENCES `tipo_articulo` (`id_tipo_articulo`),
  CONSTRAINT `articulo_ibfk_2` FOREIGN KEY (`estado`) REFERENCES `estado_articulo` (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo`
--

LOCK TABLES `articulo` WRITE;
/*!40000 ALTER TABLE `articulo` DISABLE KEYS */;
INSERT INTO `articulo` VALUES (3,'asfsafs','<p>safasfasf</p>','fdsffsd',1,3),(5,'aaa','<p>adsad</p>','aaa',1,3),(6,'Soledad','<p><iframe src=\"//www.youtube.com/embed/PyNiVDqgcsU\" width=\"420\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>','slug',1,3),(7,'pachuco bomba','<p>hola</p>','pachuco-bomba',1,3),(8,'pachuco bomba','<p>asfsaf</p>','pachuco-bomba-2',1,3),(9,'soy rumba','<p>Ui no bre es rumbra</p>','soy-rumba',1,3),(10,'Soledad','<p>Soledad soledad soleada</p>','soledad',1,3),(11,'un estilo','<p>Un estilo Socio</p>','un-estilo',1,3),(12,'Elimimiminar','<p>Ebretin eside seeeeeee</p>','elimimiminar',1,3),(13,'la indiferencia','<p>a&ntilde;&aacute;&aacute;&ntilde;&aacute;naii</p>','la-indiferencia',1,3),(14,'sis','<p>asdsd</p>','sis',1,3),(15,'Articulo de inicio','<p>You think water moves fast? You should see ice. It moves like it has a mind. Like it knows it killed the world once and got a taste for murder. After the avalanche, it took us a week to climb out. Now, I don\'t know exactly when we turned on each other, but I know that seven of us survived the slide... and only five made it out. Now we took an oath, that I\'m breaking now. We said we\'d say it was the snow that killed the other two, but it wasn\'t. Nature is lethal but it doesn\'t hold a candle to man.</p>\r\n<p>&nbsp;</p>','articulo-de-inicio',1,1),(16,'Colorganicos','<p><strong><em>Colorganicos compa&ntilde;ia de recubrimientos ....<br /></em></strong></p>\r\n<p>&nbsp;</p>\r\n<p><iframe src=\"https://www.youtube.com/embed/PKFyQn5ytiY\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\r\n<p>&nbsp;</p>','colorganicos',1,1);
/*!40000 ALTER TABLE `articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articuloxmultimedia`
--

DROP TABLE IF EXISTS `articuloxmultimedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articuloxmultimedia` (
  `id_axm` int(11) NOT NULL AUTO_INCREMENT,
  `articulo` int(11) DEFAULT NULL,
  `multimedia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_axm`),
  KEY `fk_axm_art` (`articulo`),
  KEY `fk_amx_mul` (`multimedia`),
  CONSTRAINT `articuloxmultimedia_ibfk_1` FOREIGN KEY (`articulo`) REFERENCES `articulo` (`id_articulo`),
  CONSTRAINT `articuloxmultimedia_ibfk_2` FOREIGN KEY (`multimedia`) REFERENCES `multimedia` (`id_multimedia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articuloxmultimedia`
--

LOCK TABLES `articuloxmultimedia` WRITE;
/*!40000 ALTER TABLE `articuloxmultimedia` DISABLE KEYS */;
INSERT INTO `articuloxmultimedia` VALUES (1,16,2),(2,16,1);
/*!40000 ALTER TABLE `articuloxmultimedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_5f412f9a` (`group_id`),
  KEY `auth_group_permissions_83d7f98b` (`permission_id`),
  CONSTRAINT `group_id_refs_id_f4b32aac` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `permission_id_refs_id_6ba0f519` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_37ef4eb4` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_d043b34a` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add user',4,'add_user'),(11,'Can change user',4,'change_user'),(12,'Can delete user',4,'delete_user'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(22,'Can add estado articulo',8,'add_estadoarticulo'),(23,'Can change estado articulo',8,'change_estadoarticulo'),(24,'Can delete estado articulo',8,'delete_estadoarticulo'),(25,'Can add meta',9,'add_meta'),(26,'Can change meta',9,'change_meta'),(27,'Can delete meta',9,'delete_meta'),(28,'Can add tipo articulo',10,'add_tipoarticulo'),(29,'Can change tipo articulo',10,'change_tipoarticulo'),(30,'Can delete tipo articulo',10,'delete_tipoarticulo'),(31,'Can add articulo',11,'add_articulo'),(32,'Can change articulo',11,'change_articulo'),(33,'Can delete articulo',11,'delete_articulo'),(34,'Can add multimedia',12,'add_multimedia'),(35,'Can change multimedia',12,'change_multimedia'),(36,'Can delete multimedia',12,'delete_multimedia'),(37,'Can add tipo multimedia',13,'add_tipomultimedia'),(38,'Can change tipo multimedia',13,'change_tipomultimedia'),(39,'Can delete tipo multimedia',13,'delete_tipomultimedia'),(40,'Can add articuloxmultimedia',14,'add_articuloxmultimedia'),(41,'Can change articuloxmultimedia',14,'change_articuloxmultimedia'),(42,'Can delete articuloxmultimedia',14,'delete_articuloxmultimedia');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$12000$hqqT7DBFEuZN$xdBb4+AZrCKIxwXQZ0NCQxoc374kKQzmUmrG1P6PxUw=','2017-05-31 03:44:00',1,'pablopalillo','','','pablopalillo@openmailbox.org',1,1,'2016-02-10 22:07:47');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_6340c63c` (`user_id`),
  KEY `auth_user_groups_5f412f9a` (`group_id`),
  CONSTRAINT `group_id_refs_id_274b862c` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `user_id_refs_id_40c41112` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_6340c63c` (`user_id`),
  KEY `auth_user_user_permissions_83d7f98b` (`permission_id`),
  CONSTRAINT `permission_id_refs_id_35d9ac25` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `user_id_refs_id_4dc23c39` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_6340c63c` (`user_id`),
  KEY `django_admin_log_37ef4eb4` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_93d2d1f8` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `user_id_refs_id_c0d12874` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (2,'2016-02-14 23:29:08',1,11,'1','Mision',1,''),(3,'2016-02-15 20:41:44',1,11,'1','Yo soy rumba',2,'Modificado/a contenido.'),(4,'2016-02-15 20:42:46',1,11,'2','vive 100',1,''),(5,'2016-03-15 04:57:25',1,11,'3','asfsafs',1,''),(6,'2016-03-15 05:14:15',1,11,'2','vive 100',3,''),(7,'2016-03-15 05:20:37',1,11,'1','Yo soy rumba',3,''),(8,'2016-03-24 03:38:27',1,11,'4','Vive 100',1,''),(9,'2016-03-24 03:53:07',1,11,'4','Vive 100',3,''),(10,'2016-03-24 04:16:19',1,11,'5','aaa',1,''),(15,'2016-03-24 04:35:58',1,11,'5','aaa',3,''),(16,'2016-03-24 04:39:30',1,11,'5','aaa',3,''),(17,'2016-03-24 04:40:50',1,11,'5','aaa',3,''),(18,'2016-03-24 04:48:06',1,11,'5','aaa',3,''),(21,'2016-03-24 04:53:45',1,11,'5','aaa',3,''),(22,'2016-03-24 04:54:04',1,11,'5','aaa',3,''),(23,'2016-03-24 04:55:30',1,11,'5','aaa',3,''),(25,'2016-03-24 04:57:06',1,11,'5','aaa',3,''),(26,'2016-03-24 04:57:13',1,11,'5','aaa',3,''),(27,'2016-03-24 04:59:57',1,11,'5','aaa',3,''),(28,'2016-03-24 05:01:24',1,11,'5','aaa',3,''),(29,'2016-03-24 05:03:38',1,11,'5','aaa',3,''),(30,'2016-03-24 05:04:35',1,11,'5','aaa',3,''),(31,'2016-03-24 05:05:56',1,11,'5','aaa',3,''),(32,'2016-03-24 05:07:26',1,11,'5','aaa',3,''),(33,'2016-03-24 05:10:01',1,11,'5','aaa',3,''),(34,'2016-03-24 05:13:01',1,11,'5','aaa',3,''),(35,'2016-03-24 05:13:29',1,11,'5','aaa',3,''),(36,'2016-03-24 05:13:56',1,11,'5','aaa',3,''),(37,'2016-03-24 05:18:07',1,11,'5','aaa',3,''),(38,'2016-03-24 05:20:50',1,11,'5','aaa',2,'Modificado/a tipo.'),(39,'2016-03-24 05:20:59',1,11,'5','aaa',2,'Modificado/a estado.'),(40,'2016-03-24 05:22:07',1,11,'5','aaa',3,''),(41,'2016-03-24 05:29:08',1,11,'5','aaa',3,''),(42,'2016-03-29 03:25:10',1,11,'6','Soledad',1,''),(43,'2016-03-29 04:45:17',1,11,'7','pachuco bomba',1,''),(44,'2016-04-10 19:04:39',1,11,'7','pachuco bomba',2,'No ha cambiado ningún campo.'),(45,'2016-04-10 19:06:48',1,11,'7','pachuco bomba',2,'No ha cambiado ningún campo.'),(46,'2016-04-10 19:28:11',1,11,'7','pachuco bomba',2,'No ha cambiado ningún campo.'),(47,'2016-04-10 19:32:09',1,11,'7','pachuco bomba',2,'No ha cambiado ningún campo.'),(48,'2016-04-10 19:39:22',1,11,'8','pachuco bomba',1,''),(49,'2016-04-10 19:55:50',1,11,'8','pachuco bomba',2,'Añadido/a \"Meta object\" meta.'),(50,'2016-04-10 20:07:48',1,11,'8','pachuco bomba',2,'Modificado/a estado.'),(51,'2016-04-10 20:08:02',1,11,'8','pachuco bomba',2,'Modificado/a estado.'),(52,'2016-04-10 20:11:23',1,11,'9','soy rumba',1,''),(53,'2016-04-10 20:12:00',1,11,'9','soy rumba',2,'Eliminado/a \"Meta object\" meta.'),(54,'2016-05-23 04:03:30',1,11,'6','Soledad',2,'Añadido/a \"Meta object\" meta.'),(55,'2016-05-23 04:03:53',1,11,'6','Soledad',2,'Modificados metatype y metadata para \"Meta object\" meta.'),(56,'2016-05-23 04:04:16',1,11,'6','Soledad',3,''),(57,'2016-05-23 04:10:18',1,11,'7','pachuco bomba',2,'Añadido/a \"Meta object\" meta.'),(58,'2016-05-23 04:12:26',1,11,'10','Soledad',1,''),(59,'2016-05-23 04:16:16',1,11,'9','soy rumba',3,''),(60,'2016-05-23 04:18:20',1,11,'11','un estilo',1,''),(61,'2016-05-23 04:18:37',1,11,'11','un estilo',3,''),(62,'2016-05-23 04:19:43',1,11,'12','Elimimiminar',1,''),(63,'2016-05-23 04:20:00',1,11,'12','Elimimiminar',3,''),(64,'2016-05-23 04:28:01',1,11,'13','la indiferencia',1,''),(65,'2016-05-23 04:38:06',1,11,'14','sis',1,''),(66,'2016-06-01 04:11:21',1,11,'14','sis',2,'Añadido/a \"Meta object\" meta. Modificados metatype para \"Meta object\" meta.'),(67,'2016-11-13 01:32:07',1,11,'15','Articulo de inicio',1,''),(68,'2016-11-13 02:14:11',1,12,'1','Gi regular',1,''),(69,'2016-11-28 02:37:58',1,12,'1','Gi regular',2,'No ha cambiado ningún campo.'),(70,'2016-11-28 03:37:00',1,12,'1','Gi regular',3,''),(71,'2016-11-28 03:37:38',1,12,'2','Hola soy un hp',1,''),(72,'2016-11-28 04:21:26',1,12,'2','Hola soy un hp',2,'Modificado/a url.'),(73,'2016-11-28 04:27:00',1,12,'2','Hola soy un hp',2,'Modificado/a url.'),(74,'2016-12-12 03:32:09',1,12,'2','Hola soy un hp',2,'Modificado/a tipo.'),(75,'2016-12-12 03:39:52',1,11,'15','Articulo de inicio',2,'Modificado/a contenido.'),(76,'2017-04-30 01:59:03',1,11,'16','Hola soy chelpo',1,''),(77,'2017-04-30 02:02:49',1,11,'16','Colorganicos',2,'Modificado/a nombre, contenido y slug.'),(78,'2017-05-01 18:34:57',1,11,'15','Articulo de inicio',2,'Modificado/a estado.'),(79,'2017-05-01 18:35:28',1,11,'15','Articulo de inicio',2,'Modificado/a estado.'),(80,'2017-05-01 19:01:57',1,11,'16','Colorganicos',2,'Añadido/a \"Meta object\" meta. Añadido/a \"Meta object\" meta.'),(81,'2017-05-14 17:11:37',1,12,'2','Hola soy un hp',2,'No ha cambiado ningún campo.'),(82,'2017-05-14 17:12:01',1,12,'2','Comida ',2,'Modificado/a titulo y descripcion.'),(83,'2017-05-14 17:17:24',1,12,'2','Comida ',2,'No ha cambiado ningún campo.'),(84,'2017-05-14 17:23:14',1,12,'2','Comida ',2,'No ha cambiado ningún campo.'),(85,'2017-05-14 17:32:13',1,12,'2','Comida ',2,'Modificado/a url.'),(86,'2017-05-14 17:42:49',1,12,'2','Comida ',2,'Modificado/a url.'),(87,'2017-05-15 00:53:48',1,11,'16','Colorganicos',2,'Añadido/a \"Articuloxmultimedia object\" articuloxmultimedia.'),(88,'2017-05-15 02:42:50',1,12,'2','Comida ',3,''),(89,'2017-05-31 03:40:48',1,12,'1','imagen 1 ',1,''),(90,'2017-05-31 03:41:13',1,12,'2','2',1,''),(91,'2017-05-31 03:43:15',1,12,'1','imagen 1 ',2,'Modificado/a estado.'),(92,'2017-05-31 03:43:37',1,11,'16','Colorganicos',2,'No ha cambiado ningún campo.'),(93,'2017-05-31 03:44:40',1,12,'3','ss',1,''),(94,'2017-05-31 03:57:06',1,11,'16','Colorganicos',2,'Añadido/a \"Articuloxmultimedia object\" articuloxmultimedia. Añadido/a \"Articuloxmultimedia object\" articuloxmultimedia.');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'log entry','admin','logentry'),(2,'permission','auth','permission'),(3,'group','auth','group'),(4,'user','auth','user'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(8,'estado articulo','articulo','estadoarticulo'),(9,'meta','articulo','meta'),(10,'tipo articulo','articulo','tipoarticulo'),(11,'articulo','articulo','articulo'),(12,'multimedia','multimedia','multimedia'),(13,'tipo multimedia','multimedia','tipomultimedia'),(14,'articuloxmultimedia','multimedia','articuloxmultimedia');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_b7b81f0c` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('3a14j5aueo6id433r3g3voszj4bi5kzj','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2017-05-14 01:57:42'),('4psoonpdnhhe2k4448eyasfpea52u2zt','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2017-03-30 03:23:40'),('7tekvlp6tchn8f5bubkkn02ms3sfa9o4','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-06-06 03:49:15'),('cyyqf6229c2pgbkirpwmjcg480o9hrjg','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-07-03 19:22:44'),('fgvp8gorob4r7yjjs78m63ogb5j58kqh','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-04-12 03:24:01'),('i48k8g285i7lr2ptaqp7h4leacdjoxub','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-12-26 03:13:46'),('ldnx2bgzyccxaeqeom20mupk7o99smdl','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-03-13 06:00:44'),('mcwk3do5h47nco4boi361u3g4s36an65','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2017-06-14 03:44:00'),('o0fsgarcsgop8es8yglkkpj017cctvhl','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-03-29 01:54:49'),('q08yhzvidhew91m6f7amsczb7kk4qjgy','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2017-05-28 16:54:28'),('yytjvapss42naqitgaokbjwhjxve9eu8','MWQwNmU2MzM2NjY1MGYxMWI2MDU2N2I0NGMzMTkxZWJkNDVjNzljNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2016-11-27 01:28:22');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_articulo`
--

DROP TABLE IF EXISTS `estado_articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_articulo` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(40) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_articulo`
--

LOCK TABLES `estado_articulo` WRITE;
/*!40000 ALTER TABLE `estado_articulo` DISABLE KEYS */;
INSERT INTO `estado_articulo` VALUES (1,'Publicado'),(2,'Despublicado'),(3,'Archivado');
/*!40000 ALTER TABLE `estado_articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta`
--

DROP TABLE IF EXISTS `meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta` (
  `id_meta` int(11) NOT NULL AUTO_INCREMENT,
  `id_articulo` int(11) NOT NULL,
  `metatype` varchar(35) DEFAULT NULL,
  `metadata` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_meta`),
  KEY `fk_art_met` (`id_articulo`),
  CONSTRAINT `meta_ibfk_1` FOREIGN KEY (`id_articulo`) REFERENCES `articulo` (`id_articulo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta`
--

LOCK TABLES `meta` WRITE;
/*!40000 ALTER TABLE `meta` DISABLE KEYS */;
INSERT INTO `meta` VALUES (1,8,'sizas','hola si'),(2,9,'descripcion','Hola si'),(3,6,'descripcion','Soy un sitio capz de solucionar estas cosas'),(4,7,'soy una','mierda'),(5,10,'Hola','Si'),(10,13,'sizas','sizas la inferencia'),(11,16,'keywords','colorganicos'),(12,16,'description','Compañia de recubrimientos organicos ');
/*!40000 ALTER TABLE `meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimedia`
--

DROP TABLE IF EXISTS `multimedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimedia` (
  `id_multimedia` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` int(11) NOT NULL,
  `titulo` varchar(80) DEFAULT NULL,
  `descripcion` text,
  `url` varchar(1000) DEFAULT NULL,
  `estado` char(1) DEFAULT NULL,
  PRIMARY KEY (`id_multimedia`),
  KEY `fk_mult_tipmul` (`tipo`),
  CONSTRAINT `multimedia_ibfk_1` FOREIGN KEY (`tipo`) REFERENCES `tipo_multimedia` (`id_tipo_multimedia`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimedia`
--

LOCK TABLES `multimedia` WRITE;
/*!40000 ALTER TABLE `multimedia` DISABLE KEYS */;
INSERT INTO `multimedia` VALUES (1,3,'imagen 1 ','hola ','images/image1.jpg','2'),(2,3,'2','yola32','images/image2.jpg','1'),(3,2,'ss','sdd','images/image3.jpg','1');
/*!40000 ALTER TABLE `multimedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_articulo`
--

DROP TABLE IF EXISTS `tipo_articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_articulo` (
  `id_tipo_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(40) NOT NULL,
  PRIMARY KEY (`id_tipo_articulo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_articulo`
--

LOCK TABLES `tipo_articulo` WRITE;
/*!40000 ALTER TABLE `tipo_articulo` DISABLE KEYS */;
INSERT INTO `tipo_articulo` VALUES (1,'articulo'),(2,'galería'),(3,'portafolio');
/*!40000 ALTER TABLE `tipo_articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_multimedia`
--

DROP TABLE IF EXISTS `tipo_multimedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_multimedia` (
  `id_tipo_multimedia` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(30) NOT NULL,
  PRIMARY KEY (`id_tipo_multimedia`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_multimedia`
--

LOCK TABLES `tipo_multimedia` WRITE;
/*!40000 ALTER TABLE `tipo_multimedia` DISABLE KEYS */;
INSERT INTO `tipo_multimedia` VALUES (1,'Thumbnail'),(2,'Full'),(3,'Gallery'),(4,'Banner');
/*!40000 ALTER TABLE `tipo_multimedia` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-19 14:46:53
